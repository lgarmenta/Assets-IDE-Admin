﻿CREATE TABLE [Lists].[InvitationStatuses] (
    [Id]   TINYINT       NOT NULL,
    [Name] NVARCHAR (50) NOT NULL,
    CONSTRAINT [pk_InvitationStatuses_c_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

