﻿CREATE TABLE [Lists].[MaritalStatuses] (
    [Id]   TINYINT       NOT NULL,
    [Name] NVARCHAR (50) NOT NULL,
    CONSTRAINT [pk_MaritalStatuses_c_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

