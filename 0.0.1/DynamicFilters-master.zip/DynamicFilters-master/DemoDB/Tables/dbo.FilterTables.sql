﻿CREATE TABLE [dbo].[FilterTables] (
    [FilterTableAlias] [sysname] NOT NULL,
    [FilterTableName]  [sysname] NOT NULL,
    PRIMARY KEY CLUSTERED ([FilterTableAlias] ASC)
);

