﻿CREATE TABLE [Lists].[Countries] (
    [Id]   TINYINT       NOT NULL,
    [Name] NVARCHAR (50) NOT NULL,
    CONSTRAINT [pk_Countries_c_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

