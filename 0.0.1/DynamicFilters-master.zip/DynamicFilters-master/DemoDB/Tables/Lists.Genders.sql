﻿CREATE TABLE [Lists].[Genders] (
    [Id]   TINYINT       NOT NULL,
    [Name] NVARCHAR (50) NOT NULL,
    CONSTRAINT [pk_Genders_c_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

