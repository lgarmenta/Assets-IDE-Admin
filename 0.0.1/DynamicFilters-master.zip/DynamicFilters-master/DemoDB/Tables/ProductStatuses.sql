﻿CREATE TABLE [Lists].[ProductStatuses] (
    [Id]   TINYINT       NOT NULL,
    [Name] NVARCHAR (50) NOT NULL,
    CONSTRAINT [pk_ProductStatuses_c_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

