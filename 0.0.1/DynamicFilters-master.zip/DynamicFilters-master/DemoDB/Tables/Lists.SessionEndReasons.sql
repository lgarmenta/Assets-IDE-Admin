﻿CREATE TABLE [Lists].[SessionEndReasons] (
    [Id]   TINYINT       NOT NULL,
    [Name] NVARCHAR (50) NOT NULL,
    CONSTRAINT [pk_SessionEndReasons_c_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

