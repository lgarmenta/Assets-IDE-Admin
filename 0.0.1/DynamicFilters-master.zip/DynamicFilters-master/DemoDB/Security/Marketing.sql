﻿CREATE SCHEMA [Marketing]
    AUTHORIZATION [dbo];

