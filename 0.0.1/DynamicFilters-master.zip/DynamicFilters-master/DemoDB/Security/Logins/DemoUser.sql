﻿CREATE LOGIN [demoUser] WITH PASSWORD = 'demoPassword'
