﻿CREATE SCHEMA [Inventory]
    AUTHORIZATION [dbo];

