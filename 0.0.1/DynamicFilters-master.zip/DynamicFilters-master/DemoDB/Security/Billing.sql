﻿CREATE SCHEMA [Billing]
    AUTHORIZATION [dbo];



