﻿CREATE SCHEMA [Operation]
    AUTHORIZATION [dbo];

